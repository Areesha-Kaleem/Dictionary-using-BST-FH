#include <fmx.h>
#include <windows.h>
#include <algorithm>
#include <fstream>
#include <string>
#pragma hdrstop

#include "dsaCE15.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;

__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner), root(NULL)
{
}

void __fastcall TForm1::FormCreate(TObject *Sender)
{
    loadDictionary();
    ShowMessage("Dictionary Loaded");
}

void TForm1::loadDictionary()
{
    std::ifstream file("D:\\DSA Lab\\Dictionary.txt");
    if (!file.is_open()) {
        ShowMessage("Error opening dictionary file");
        return;
    }
    std::string word;
    while (std::getline(file, word)) {
        insertToBST(word);
    }
    file.close();
}

void TForm1::insertToBST(std::string word)
{
    int weight = calculateWeight(word);
    if (!root) {
        root = new node{ word, weight, NULL, NULL };
    } else {
        struct node* temp = root;
        while (true) {
            if (weight < temp->weight_of_word) {
                if (!temp->left) {
                    temp->left = new node{ word, weight, NULL, NULL };
                    break;
                }
                temp = temp->left;
            } else if (weight > temp->weight_of_word) {
                if (!temp->right) {
                    temp->right = new node{ word, weight, NULL, NULL };
                    break;
                }
                temp = temp->right;
            } else {
                //ShowMessage("Duplication occurred, not inserted");
                break;
            }
        }
    }
}

int TForm1::calculateWeight(std::string word)
{
    int weight = 0;
    for (char c : word) {
        weight += (int(c) * int(c));
    }
    return weight;
}

std::string toLowerCase(const std::string &input) {
    std::string lowerCaseStr = input;
    std::transform(lowerCaseStr.begin(), lowerCaseStr.end(), lowerCaseStr.begin(), ::tolower);
    return lowerCaseStr;
}

void __fastcall TForm1::SearchButtonClick(TObject *Sender)
{
    String userInput = TextEnterField->Text;
    if (userInput.IsEmpty()) {
        ShowMessage("Please enter a word");
        return;
    }
    std::string lowerCaseInput = toLowerCase(AnsiString(userInput).c_str());
    searchAndSuggest(lowerCaseInput);
}

void TForm1::searchAndSuggest(std::string word)
{
    int weight = calculateWeight(word);
    node* temp = root;
    bool found = false;
    while (temp) {
        if (temp->data == word) {
            found = true;
            break;
        } else if (weight < temp->weight_of_word) {
            temp = temp->left;
        } else {
            temp = temp->right;
        }
    }

    if (found) {
        ShowMessagePos("Word found in the dictionary", 0, 0);
        TextEnterField->Text = "";
    } else {
        ListBoxtodisplaySuggestions->Clear();
        spell_corrector(root, word);
        Timer1->Enabled = true; // Enable the timer to delay before suggesting
    }
}

void TForm1::spell_corrector(struct node* root, std::string str22)
{
    if (!root) return;
    std::string fin = root->data;
    if (abs((int)fin.size() - (int)str22.size()) <= 2) {
        int hit = 0;
        for (size_t o = 0; o < str22.size() && o < fin.size(); o++) {
            if (str22[o] == fin[o]) hit++;
        }
        int hitrate = (hit * 100) / str22.size();
        if (hitrate >= 50) {
            ListBoxtodisplaySuggestions->Items->Add(fin.c_str());
        }
    }
    spell_corrector(root->left, str22);
    spell_corrector(root->right, str22);
}

void __fastcall TForm1::ExitButtonClick(TObject *Sender)
{
    Application->Terminate();
}

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    Timer1->Enabled = false; // Disable the timer after it fires

    if (ListBoxtodisplaySuggestions->Count > 0) {
        int response = MessageDlgPos("Word not found. Was it in the suggestions?",
                                  TMsgDlgType::mtConfirmation, TMsgDlgButtons() << TMsgDlgBtn::mbYes << TMsgDlgBtn::mbNo, 0, 0, 0);
        if (response == mrYes) {
            TextEnterField->Text = "";
            ListBoxtodisplaySuggestions->Clear();
        } else if (response == mrNo) {
            int addToDictResponse = MessageDlgPos("Add the word to the dictionary?", TMsgDlgType::mtConfirmation, TMsgDlgButtons() << TMsgDlgBtn::mbYes << TMsgDlgBtn::mbNo, 0, 0, 0);
            if (addToDictResponse == mrYes) {
                std::string word = toLowerCase(AnsiString(TextEnterField->Text).c_str());
                insertToBST(word);
                std::ofstream file("D:\\DSA Lab\\Dictionary.txt", std::ios::app);
                if (file.is_open()) {
                    file << word << std::endl;
                    file.close();
                    ShowMessagePos("Word added to dictionary", 0, 0);
                    TextEnterField->Text = "";
                    ListBoxtodisplaySuggestions->Clear();
                }
            } else {
                TextEnterField->Text = "";
                ListBoxtodisplaySuggestions->Clear();
            }
        }
    } else {
        int addToDictResponse = MessageDlgPos("Word not found. Add the word to the dictionary?", TMsgDlgType::mtConfirmation, TMsgDlgButtons() << TMsgDlgBtn::mbYes << TMsgDlgBtn::mbNo, 0, 250, 100);
        if (addToDictResponse == mrYes) {
            std::string word = toLowerCase(AnsiString(TextEnterField->Text).c_str());
            insertToBST(word);
            std::ofstream file("D:\\DSA Lab\\Dictionary.txt", std::ios::app);
            if (file.is_open()) {
                file << word << std::endl;
                file.close();
                ShowMessagePos("Word added to dictionary", 0, 0);
                TextEnterField->Text = "";
                ListBoxtodisplaySuggestions->Clear();
            }
        } else {
            TextEnterField->Text = "";
            ListBoxtodisplaySuggestions->Clear();
        }
    }
}

