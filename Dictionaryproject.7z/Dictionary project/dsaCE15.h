#ifndef dsaCE15H
#define dsaCE15H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Objects.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.Types.hpp>
#include <FMX.Edit.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.ListBox.hpp>
#include <FMX.Dialogs.hpp>
//---------------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct node {
    string data;
    int weight_of_word;
    struct node* right;
    struct node* left;
};

class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *Image1;
	TLabel *Label1;
	TImage *Image2;
	TRectangle *Rectangle1;
	TLabel *Label2;
	TEdit *TextEnterField;
	TButton *SearchButton;
	TButton *ExitButton;
	TListBox *ListBoxtodisplaySuggestions;
	TTimer *Timer1;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall SearchButtonClick(TObject *Sender);
	void __fastcall ExitButtonClick(TObject *Sender);
	void __fastcall Timer1Timer(TObject *Sender);
private:
	struct node* root;
	void loadDictionary();
	void insertToBST(string word);
	void searchAndSuggest(string word);
	int calculateWeight(string word);
	void spell_corrector(struct node* root, string str22);
public:
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

